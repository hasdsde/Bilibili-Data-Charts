import{ap as e}from"./index.5d1b3584.js";const r={};function n(a,c){return null}var _=e(r,[["render",n]]);export{_ as default};
