import{ap as e}from"./index.59bf5afc.js";const r={};function n(a,c){return null}var _=e(r,[["render",n]]);export{_ as default};
